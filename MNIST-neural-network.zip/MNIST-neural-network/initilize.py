import numpy as np
def initilization():
    np.random.seed(42)
    learning_rate=0.1
    epoch=30
    input_neuron=784
    hidden1_neuron=128
    hidden2_neuron=128
    output_neuron=10

    w1=np.random.randn(input_neuron,hidden1_neuron)*0.1
    w2=np.random.randn(hidden1_neuron,hidden2_neuron)*0.1
    w3=np.random.randn(hidden2_neuron,output_neuron)*0.1

    b1=np.ones((1,hidden1_neuron))*0.01
    b2=np.ones((1,hidden2_neuron))*0.01
    b3=np.zeros((1,output_neuron))

    return w1,w2,w3,b1,b2,b3,learning_rate,epoch



