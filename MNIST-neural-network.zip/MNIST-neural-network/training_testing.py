import numpy as np

def training_testing():
    #Use train_data if want to run program on train data else keep the code as it is.
    train_data = np.loadtxt('mnist_train.csv', delimiter=',',dtype=np.float32,skiprows=1)#60000,785
    test_data=np.loadtxt('mnist_test.csv',delimiter=',',dtype=np.float32,skiprows=1)
    X_labels=test_data[:,0]
    X_features=test_data[:,1:]
    X_features=X_features/255
    #X_features=(X_features-np.mean(X_features))/np.std(X_features)
    num_class=10
    X_labels=np.eye(num_class)[X_labels.astype(int)]
    return X_labels,X_features
