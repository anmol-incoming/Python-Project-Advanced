from training_testing import training_testing
from initilize import initilization
from relu_activation import relu_activation
from relu_derivative import relu_derivative
from softmax_activation import softmax_activation
from softmax_derivative import softmax_derivative
from model_training import model_training
from load_data import load_data
def main():
    X_labels,X_features=training_testing()
    w1,w2,w3,b1,b2,b3,learning_rate,epoch=load_data()#Put initilization() here insted if want to run on train_data
    relu=relu_activation
    relu_dev=relu_derivative
    softmax=softmax_activation
    softmax_dev=softmax_derivative
    result=model_training(X_labels,X_features,w1,w2,w3,b1,b2,b3,learning_rate,epoch,relu,relu_dev,softmax,softmax_dev)
    print(result)


run=main()
    

