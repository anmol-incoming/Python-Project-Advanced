def softmax_derivative(x,X_labels):
    softmax_dev=x-X_labels
    return softmax_dev
