import numpy as np
def relu_activation(x):
    relu=np.maximum(0,x)
    return relu