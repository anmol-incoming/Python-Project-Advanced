This is MNIST-Neural-Network using only numpy.
The process of this was simplar to XOR only thing i did was to use mini batch process instead of full batch.Load csv data .Used 2 hidden layers each with 128 neurons.Saved the weights and biases of final epoch using np.save and np.load to load weights and biases. And used sofmax activation in output layer.
The test set output program looks like this:-

Weights and biases loaded successfully!
Test Accuracy: 97.31%
Sample 0: Predicted=7, True=7
Sample 1: Predicted=2, True=2
Sample 2: Predicted=1, True=1
Sample 3: Predicted=0, True=0
Sample 4: Predicted=4, True=4
Sample 5: Predicted=1, True=1
Sample 6: Predicted=4, True=4
Sample 7: Predicted=9, True=9
Sample 8: Predicted=5, True=5
Sample 9: Predicted=9, True=9
[7 2 1 ... 4 5 6]


And in train set i got somewhere around 98% accuracy.

Thank You for reading this.Hope you have a great day.
