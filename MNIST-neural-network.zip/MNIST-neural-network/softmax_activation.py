import numpy as np
def softmax_activation(x):
    X_stable=x-np.max(x,axis=1,keepdims=True)
    X_exp=np.exp(X_stable)
    X_sum=np.sum(X_exp,axis=1,keepdims=True) 
    softmax=X_exp/X_sum
    return softmax  

