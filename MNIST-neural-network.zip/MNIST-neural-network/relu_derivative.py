import numpy as np
def relu_derivative(x,alpha=0.01):
    relu_dev=np.where(x>0,x,alpha)
    return relu_dev

