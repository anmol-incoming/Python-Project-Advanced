import numpy as np

def load_data():


# Load weights and biases
    learning_rate=0.1
    epoch=30
    w1 = np.load("w1.npy")
    w2 = np.load("w2.npy")
    w3 = np.load("w3.npy")

    b1 = np.load("b1.npy")
    b2 = np.load("b2.npy")
    b3 = np.load("b3.npy")

    print("Weights and biases loaded successfully!")
    return w1,w2,w3,b1,b2,b3,learning_rate,epoch

