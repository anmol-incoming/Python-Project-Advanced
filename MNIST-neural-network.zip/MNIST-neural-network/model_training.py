import numpy as np
def model_training(X_labels,X_features,w1,w2,w3,b1,b2,b3,learning_rate,epoch,relu,relu_dev,softmax,softmax_dev):
    #Remove this if want to use you want to train data either way the weights and biases are save in .npy files
    """
    batch_size=100
    n_samples=X_features.shape[0]
    for i in range(epoch):
        indices=np.arange(n_samples)
        np.random.shuffle(indices)
        X_features=X_features[indices]
        X_labels=X_labels[indices]

        for i in range(0,n_samples,batch_size):
            X_batch=X_features[i:i+batch_size]
            Y_labels=X_labels[i:i+batch_size]
            z1=np.dot(X_batch,w1)+b1
            a1=relu(z1)
            z2=np.dot(a1,w2)+b2
            a2=relu(z2)
            z3=np.dot(a2,w3)+b3
            a3=softmax(z3)
            m_batch=Y_labels.shape[0]
            #loss=-np.mean(np.sum(X_labels *np.log(a3+1e-8),axis=1,keepdims=True))
            delta3=(a3-Y_labels)/m_batch
            delta2=relu_dev(a2)*np.dot(delta3,w3.T)
            delta1=relu_dev(a1)*np.dot(delta2,w2.T)
            def clip_grad(g):
                return np.clip(g, -1.0, 1.0)

            delta_w3=learning_rate*clip_grad(np.dot(a2.T,delta3))
            w3-=delta_w3
            delta_w2=learning_rate*clip_grad(np.dot(a1.T,delta2))
            w2-=delta_w2
            delta_w1=learning_rate*clip_grad(np.dot(X_batch.T,delta1))
            w1-=delta_w1

            delta_b3=learning_rate*clip_grad(np.sum(delta3,axis=0,keepdims=True))
            b3-=delta_b3
            delta_b2=learning_rate*clip_grad(np.sum(delta2,axis=0,keepdims=True))
            b2-=delta_b2

            delta_b1=learning_rate*clip_grad(np.sum(delta1,axis=0,keepdims=True))
            b1-=delta_b1
    # Save each weight and bias to a separate file
    np.save("w1.npy", w1)
    np.save("w2.npy", w2)
    np.save("w3.npy", w3)

    np.save("b1.npy", b1)
    np.save("b2.npy", b2)
    np.save("b3.npy", b3)

    print("Weights and biases saved successfully!")
    """

   #testing the data  
    z1 = np.dot(X_features, w1) + b1
    a1 = relu(z1)
    z2 = np.dot(a1, w2) + b2
    a2 = relu(z2)
    z3 = np.dot(a2, w3) + b3
    a3 = softmax(z3)


    
    true_classes = np.argmax(X_labels, axis=1)


    pred_classes = np.argmax(a3, axis=1)


    accuracy = np.mean(pred_classes == true_classes) * 100
    print(f"Test Accuracy: {accuracy:.2f}%")


    for i in range(10):
        print(f"Sample {i}: Predicted={pred_classes[i]}, True={true_classes[i]}")

    return pred_classes

        